export const metadata = { title: 'Admin' };

export default function AdminLayout({ children }) {
  return <>{children}</>;
}
