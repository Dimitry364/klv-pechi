/* eslint-disable @next/next/no-img-element */
import Script from 'next/script';

export default function Head() {
  return (
    <>
      {/* schema.org Organization JSON-LD */}
      <script
        suppressHydrationWarning
        type='application/ld+json'
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Organization',
            name: 'Колывань-Печи',
            url: 'https://колывань-печи.рф',
            logo: 'https://колывань-печи.рф/img/logo/Logored.svg',
            description:
              'Производство печей и бездымных костровых чаш из нержавеющей стали AISI 321 с доставкой по всей России.',
            address: {
              '@type': 'PostalAddress',
              addressCountry: 'RU',
            },
            contactPoint: {
              '@type': 'ContactPoint',
              telephone: '+7-951-364-55-66',
              contactType: 'sales',
              areaServed: 'RU',
            },
            sameAs: [
              'https://t.me/+79513645566',
              'https://wa.me/79513645566',
              'https://vk.com/club229742329',
            ],
          }),
        }}
      />

      {/* Яндекс метрика */}
      <Script
        id='yandex-metrika'
        strategy='afterInteractive'
        dangerouslySetInnerHTML={{
          __html: `
              (function(m,e,t,r,i,k,a){
                  m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
                  m[i].l=1*new Date();
                  for (var j = 0; j < document.scripts.length; j++) {
                    if (document.scripts[j].src === r) { return; }
                  }
                  k = e.createElement(t);
                  a = e.getElementsByTagName(t)[0];
                  k.async = 1;
                  k.src = r;
                  a.parentNode.insertBefore(k,a)
              })(window, document,'script','https://mc.yandex.ru/metrika/tag.js?id=105456265', 'ym');

              ym(105456265, 'init', {
                ssr: true,
                webvisor: true,
                clickmap: true,
                ecommerce: "dataLayer",
                accurateTrackBounce: true,
                trackLinks: true
              });
            `,
        }}
      />
      <noscript>
        <div>
          <img
            src='https://mc.yandex.ru/watch/105456265'
            style={{ position: 'absolute', left: '-9999px' }}
            alt=''
          />
        </div>
      </noscript>
    </>
  );
}
