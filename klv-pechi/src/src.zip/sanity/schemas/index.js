import product from './product';
import category from './category';
import specPair from './specPair';
import option from './option';
import galleryItem from './galleryItem';

// eslint-disable-next-line import/no-anonymous-default-export
export default [product, category, specPair, option, galleryItem];
